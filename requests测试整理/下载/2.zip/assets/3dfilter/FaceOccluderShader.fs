precision highp float;

varying vec2 fragTexCoord;

void main() {
    gl_FragColor = vec4(0, 0, 0, 0);
}
